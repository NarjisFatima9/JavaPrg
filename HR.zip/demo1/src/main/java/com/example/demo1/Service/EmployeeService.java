package com.example.demo1.Service;

import com.example.demo1.Entity.Employee;

import java.util.List;

public interface EmployeeService {

    List<Employee> getAllEmployee();

}
