package com.example.demo1.Service;

import com.example.demo1.Entity.Employee;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmpServiceImpl  implements EmployeeService{
    List<Employee> list;

    public EmpServiceImpl() {
        list = new ArrayList<>();
        list.add(new Employee(101, "John", "Acts"));
        list.add(new Employee(102, "John","Acts"));
        list.add(new Employee(103, "John","Acts"));


    }

    @Override
    public List<Employee> getAllEmployee() {
        return list;
    }
}
