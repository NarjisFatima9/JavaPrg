package com.example.demo1.Entity;

public class Employee {
    private int empid;
    private String empname;
    private String empdept;
    public Employee(){}
    public Employee(int empid,String empname, String empdept){
        this.empid = empid;
        this.empname = empname;
        this.empdept = empdept;

    }

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getEmpdept() {
        return empdept;
    }

    public void setEmpdept(String empdept) {
        this.empdept = empdept;
    }
}
