package com.example.demo1.Controller;

import com.example.demo1.Entity.Employee;
import com.example.demo1.Service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MyController {

   @Autowired
    private EmployeeService employeeService;
   @GetMapping("/")
    public String home()

    {
        return "wellcome";
    }
   @GetMapping("/Employee")
    public List<Employee> getEmployee()
    {
       return this.employeeService.getAllEmployee();
    }

}
